----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 25.02.2026 23:19:28
-- Design Name: 
-- Module Name: decoder - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity decoder is
  Port (       
        C1 : in  STD_LOGIC;
        C2 : in  STD_LOGIC;
        D  : in  STD_LOGIC_VECTOR (3 downto 0);
        Y  : out STD_LOGIC_VECTOR (15 downto 0)
    );
end decoder;

architecture Behavioral of decoder is
 signal enable : STD_LOGIC;
begin
 enable <= C1 and C2;

    process(D, enable)
    begin
        if enable = '1' then
            Y <= (others => '0');
            Y(to_integer(unsigned(D))) <= '1';
        else
            Y <= (others => '0');
        end if;
    end process;

end Behavioral;
